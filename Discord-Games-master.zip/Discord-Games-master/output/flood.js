"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const game_base_1 = __importDefault(require("./game-base"));
const game_result_1 = require("./game-result");
const position_1 = require("./position");
const discord_minimal_1 = require("discord-minimal");
const WIDTH = 13;
const HEIGHT = 13;
const SQUARES = { 'red_square': '🟥', 'blue_square': '🟦', 'orange_square': '🟧', 'purple_square': '🟪', 'green_square': '🟩' };
class FloodGame extends game_base_1.default {
    constructor() {
        super('flood', false);
        this.gameBoard = Array.from({ length: WIDTH * HEIGHT }, () => Object.values(SQUARES)[Math.floor(Math.random() * Object.keys(SQUARES).length)]);
        this.turn = 1;
    }
    gameBoardToString() {
        let str = '';
        for (let y = 0; y < HEIGHT; y++) {
            for (let x = 0; x < WIDTH; x++) {
                str += this.gameBoard[y * WIDTH + x];
            }
            str += '\n';
        }
        return str;
    }
    getBaseEmbed() {
        return new discord_minimal_1.DiscordEmbed()
            .setColor('#08b9bf')
            .setTitle('Flood')
            .setAuthor('Made By: Eric', 'https://i.ibb.co/xXZxMT0/1.webp[/img][/url]')
            .setTimestamp();
    }
    getContent() {
        const row = new discord_minimal_1.DiscordMessageActionRow()
            .addComponents(...Object.entries(SQUARES).map(([k, v]) => new discord_minimal_1.DiscordMessageButton(discord_minimal_1.DiscordButtonStyle.SECONDARY)
            .setCustomId(k)
            .setLabel(v)));
        const embed = this.getBaseEmbed()
            .setDescription(this.gameBoardToString())
            .addField('Turn:', this.turn.toString())
            .setFooter(`Currently Playing: ${this.gameStarter.username}`);
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [embed];
        resp.components = [row];
        return resp;
    }
    getGameOverContent(result) {
        const turnResp = result.result == game_result_1.ResultType.WINNER ? `Game beat in ${this.turn - 1} turns!` : '';
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [this.getBaseEmbed().setDescription(`GAME OVER!\n${turnResp}`).setFooter(`Player: ${this.gameStarter.username}`)];
        return resp;
    }
    onInteraction(interaction) {
        if (!interaction.isButton())
            return;
        const selected = Object.entries(SQUARES).find(([k, v]) => k === interaction.data?.custom_id);
        const current = this.gameBoard[0];
        if (selected && selected[1] !== current) {
            this.turn += 1;
            const queue = [{ x: 0, y: 0 }];
            const visited = [];
            while (queue.length > 0) {
                const pos = queue.shift();
                if (!pos || visited.some(p => p.x === pos.x && p.y === pos.y))
                    continue;
                visited.push(pos);
                if (this.gameBoard[pos.y * WIDTH + pos.x] === current) {
                    this.gameBoard[pos.y * WIDTH + pos.x] = selected[1];
                    [(0, position_1.up)(pos), (0, position_1.down)(pos), (0, position_1.left)(pos), (0, position_1.right)(pos)].forEach(checkPos => {
                        if (!visited.some(p => p.x === checkPos.x && p.y === checkPos.y) && (0, position_1.isInside)(checkPos, WIDTH, HEIGHT))
                            queue.push(checkPos);
                    });
                }
            }
            const gameOver = !this.gameBoard.find(t => t !== selected[1]);
            if (gameOver)
                this.gameOver({ result: game_result_1.ResultType.WINNER, score: (this.turn - 1).toString() }, interaction);
            else
                super.step(false);
        }
        if (this.isInGame())
            interaction.update(this.getContent()).catch(e => super.handleError(e, 'update interaction'));
        else if (!this.result)
            this.gameOver({ result: game_result_1.ResultType.ERROR }, interaction);
    }
    onReaction(reaction) { }
}
exports.default = FloodGame;
