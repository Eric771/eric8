"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const game_result_1 = require("./game-result");
const game_base_1 = __importDefault(require("./game-base"));
const discord_minimal_1 = require("discord-minimal");
const WIDTH = 7;
const HEIGHT = 7;
class Connect4Game extends game_base_1.default {
    constructor() {
        super('connect4', true);
        this.gameBoard = Array.from({ length: WIDTH * HEIGHT }, () => '⚪');
    }
    gameBoardToString() {
        let str = '';
        if (!this.player2)
            str += 'Note there is no AI for this game, so you are just playing against yourself';
        str += '\n|1️⃣|2️⃣|3️⃣|4️⃣|5️⃣|6️⃣|7️⃣|\n';
        for (let y = 0; y < HEIGHT; y++) {
            for (let x = 0; x < WIDTH; x++)
                str += '|' + this.gameBoard[y * WIDTH + x];
            str += '|\n';
        }
        return str;
    }
    newGame(interaction, player2, onGameEnd) {
        if (super.isInGame())
            return;
        this.gameBoard = Array.from({ length: WIDTH * HEIGHT }, () => '⚪');
        super.newGame(interaction, player2, onGameEnd);
    }
    getBaseEmbed() {
        return new discord_minimal_1.DiscordEmbed()
            .setColor('#000b9e')
            .setTitle('Connect-4')
            .setAuthor('Made By: Eric', 'https://i.ibb.co/xXZxMT0/1.webp[/img][/url]')
            .setTimestamp();
    }
    getContent() {
        const row1 = super.createMessageActionRowButton([['1', '1️⃣'], ['2', '2️⃣'], ['3', '3️⃣'], ['4', '4️⃣']]);
        const row2 = super.createMessageActionRowButton([['5', '5️⃣'], ['6', '6️⃣'], ['7', '7️⃣']]);
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [this.getBaseEmbed()
                .setDescription(this.gameBoardToString())
                .addField('Turn:', this.getUserDisplay())
                .setFooter(`Currently Playing: ${this.gameStarter.username}`)];
        resp.components = [row1, row2];
        return resp;
    }
    getGameOverContent(result) {
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [this.getBaseEmbed().setDescription(`**GAME OVER! ${this.getWinnerText(result)}**\n\n${this.gameBoardToString()}`)];
        return resp;
    }
    step() {
        this.player1Turn = !this.player1Turn;
        super.step(false);
    }
    onReaction(reaction) { }
    onInteraction(interaction) {
        const sender = interaction.member?.user?.id;
        const turnPlayerId = this.player1Turn ? this.gameStarter.id : (this.player2 ? this.player2.id : this.gameStarter.id);
        if (sender !== turnPlayerId) {
            interaction.deferUpdate().catch(e => super.handleError(e, 'defer interaction'));
            return;
        }
        const customId = interaction.data?.custom_id;
        if (!customId) {
            this.step();
            interaction.deferUpdate().catch(e => super.handleError(e, 'defer interaction'));
            return;
        }
        let column = parseInt(customId);
        if (column === undefined) {
            interaction.deferUpdate().catch(e => super.handleError(e, 'defer interaction'));
            return;
        }
        column -= 1;
        let placedX = -1;
        let placedY = -1;
        for (let y = HEIGHT - 1; y >= 0; y--) {
            const chip = this.gameBoard[column + (y * WIDTH)];
            if (chip === '⚪') {
                this.gameBoard[column + (y * WIDTH)] = this.getChipFromTurn();
                placedX = column;
                placedY = y;
                break;
            }
        }
        if (this.hasWon(placedX, placedY)) {
            this.gameOver({ result: game_result_1.ResultType.WINNER, name: this.getUserDisplay(), score: this.getScore() }, interaction);
        }
        else if (this.isBoardFull()) {
            this.gameOver({ result: game_result_1.ResultType.TIE, score: this.getScore() }, interaction);
        }
        else {
            this.step();
            interaction.update(this.getContent()).catch(e => super.handleError(e, 'update interaction'));
        }
    }
    getScore() {
        return this.gameBoard.map(chip => chip === '⚪' ? '0' : (chip === '🔴' ? '1' : '2')).join('');
    }
    getUserDisplay() {
        if (this.isMultiplayerGame && this.player2)
            return this.player1Turn ? '🔴 ' + this.gameStarter.username : '🟡 ' + this.player2?.username ?? 'ERR';
        return this.getChipFromTurn();
    }
    getChipFromTurn() {
        return this.player1Turn ? '🔴' : '🟡';
    }
    hasWon(placedX, placedY) {
        const chip = this.getChipFromTurn();
        //Horizontal Check
        const y = placedY * WIDTH;
        for (let i = Math.max(0, placedX - 3); i <= Math.min(placedX, WIDTH - 1); i++) {
            const adj = i + y;
            if (i + 3 < WIDTH) {
                if (this.gameBoard[adj] === chip && this.gameBoard[adj + 1] === chip && this.gameBoard[adj + 2] === chip && this.gameBoard[adj + 3] === chip)
                    return true;
            }
        }
        //Vertical Check
        for (let i = Math.max(0, placedY - 3); i <= Math.min(placedY, HEIGHT - 1); i++) {
            const adj = placedX + (i * WIDTH);
            if (i + 3 < HEIGHT) {
                if (this.gameBoard[adj] === chip && this.gameBoard[adj + WIDTH] === chip && this.gameBoard[adj + (2 * WIDTH)] === chip && this.gameBoard[adj + (3 * WIDTH)] === chip)
                    return true;
            }
        }
        //Ascending Diag
        for (let i = -3; i <= 0; i++) {
            const adjX = placedX + i;
            const adjY = placedY + i;
            if (adjX < 0 || adjY < 0)
                continue;
            const adj = adjX + (adjY * WIDTH);
            if (adjX + 3 < WIDTH && adjY + 3 < HEIGHT) {
                if (this.gameBoard[adj] === chip && this.gameBoard[adj + WIDTH + 1] === chip && this.gameBoard[adj + (2 * WIDTH) + 2] === chip && this.gameBoard[adj + (3 * WIDTH) + 3] === chip)
                    return true;
            }
        }
        //Descending Diag
        for (let i = -3; i <= 0; i++) {
            const adjX = placedX + i;
            const adjY = placedY - i;
            if (adjX < 0 || adjY < 0)
                continue;
            const adj = adjX + (adjY * WIDTH);
            if (adjX + 3 < WIDTH && adjY - 3 >= 0) {
                if (this.gameBoard[adj] === chip && this.gameBoard[adj - WIDTH + 1] === chip && this.gameBoard[adj - (2 * WIDTH) + 2] === chip && this.gameBoard[adj - (3 * WIDTH) + 3] === chip)
                    return true;
            }
        }
        return false;
    }
    isBoardFull() {
        return !this.gameBoard.includes('⚪');
    }
}
exports.default = Connect4Game;
