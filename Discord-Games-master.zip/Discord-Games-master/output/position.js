"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isInside = exports.posEqual = exports.move = exports.right = exports.left = exports.down = exports.up = void 0;
const direction_1 = require("./direction");
const up = (pos) => ({ x: pos.x, y: pos.y - 1 });
exports.up = up;
const down = (pos) => ({ x: pos.x, y: pos.y + 1 });
exports.down = down;
const left = (pos) => ({ x: pos.x - 1, y: pos.y });
exports.left = left;
const right = (pos) => ({ x: pos.x + 1, y: pos.y });
exports.right = right;
const move = (pos, dir) => {
    switch (dir) {
        case direction_1.Direction.UP:
            return (0, exports.up)(pos);
        case direction_1.Direction.DOWN:
            return (0, exports.down)(pos);
        case direction_1.Direction.LEFT:
            return (0, exports.left)(pos);
        case direction_1.Direction.RIGHT:
            return (0, exports.right)(pos);
    }
};
exports.move = move;
const posEqual = (pos1, pos2) => {
    return pos1.x === pos2.x && pos1.y === pos2.y;
};
exports.posEqual = posEqual;
const isInside = (pos, width, height) => {
    return pos.x >= 0 && pos.y >= 0 && pos.x < width && pos.y < height;
};
exports.isInside = isInside;
