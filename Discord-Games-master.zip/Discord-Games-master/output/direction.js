"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.oppositeDir = exports.Direction = void 0;
var Direction;
(function (Direction) {
    Direction[Direction["UP"] = 0] = "UP";
    Direction[Direction["DOWN"] = 1] = "DOWN";
    Direction[Direction["LEFT"] = 2] = "LEFT";
    Direction[Direction["RIGHT"] = 3] = "RIGHT";
})(Direction || (exports.Direction = Direction = {}));
const oppositeDir = (dir) => {
    switch (dir) {
        case Direction.UP:
            return Direction.DOWN;
        case Direction.DOWN:
            return Direction.UP;
        case Direction.LEFT:
            return Direction.RIGHT;
        case Direction.RIGHT:
            return Direction.LEFT;
    }
};
exports.oppositeDir = oppositeDir;
