"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResultType = void 0;
var ResultType;
(function (ResultType) {
    ResultType["TIMEOUT"] = "\u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0648\u0642\u062A";
    ResultType["FORCE_END"] = "force_end";
    ResultType["WINNER"] = "\u0627\u0644\u0641\u0627\u0626\u0632";
    ResultType["LOSER"] = "\u0627\u0644\u062E\u0627\u0633\u0631";
    ResultType["TIE"] = "tie";
    ResultType["ERROR"] = "\u062D\u062F\u062B \u062E\u0637\u0623";
    ResultType["DELETED"] = "\u0645\u062D\u0630\u0648\u0641";
})(ResultType || (exports.ResultType = ResultType = {}));
