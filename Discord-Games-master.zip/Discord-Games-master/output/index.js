"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const discord_minimal_1 = require("discord-minimal");
const config_1 = require("./config");
const snake_1 = __importDefault(require("./snake"));
const hangman_1 = __importDefault(require("./hangman"));
const minesweeper_1 = __importDefault(require("./minesweeper"));
const connect4_1 = __importDefault(require("./connect4"));
const chess_1 = __importDefault(require("./chess"));
const tic_tac_toe_1 = __importDefault(require("./tic-tac-toe"));
const game_result_1 = require("./game-result");
const flood_1 = __importDefault(require("./flood"));
const _2048_1 = __importDefault(require("./2048"));
const client = new discord_minimal_1.DiscordMinimal([discord_minimal_1.INTENTS.GUILDS, discord_minimal_1.INTENTS.GUILD_MESSAGES, discord_minimal_1.INTENTS.GUILD_MESSAGE_REACTIONS]);
const commandGameMap = {
    'snake': () => new snake_1.default(),
    'hangman': () => new hangman_1.default(),
    'connect4': () => new connect4_1.default(),
    'minesweeper': () => new minesweeper_1.default(),
    'chess': () => new chess_1.default(),
    'tictactoe': () => new tic_tac_toe_1.default(),
    'flood': () => new flood_1.default(),
    '2048': () => new _2048_1.default(),
};
const playerGameMap = new Map();
client.on('ready', (ready) => {
    ready.user.setActivity('!gbhelp');
    console.log(`Logged in as ${ready.user?.username}!`);
    initCommands(ready.application.id);
});
function initCommands(appId) {
    const vsSubCommand = new discord_minimal_1.DiscordApplicationCommandOption('vs', 'User you wish to play against', discord_minimal_1.DiscordApplicationCommandOptionType.USER);
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, 'gamesbot', 'GamesBot help and info'));
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, 'listgames', 'List available games'));
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, 'endgame', 'End the game you are currently playing'));
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, 'snake', 'Play Snake'));
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, 'hangman', 'Play Hangman'));
    const connect4Command = new discord_minimal_1.DiscordApplicationCommand(appId, 'connect4', 'Play Connect4');
    connect4Command.addOption(vsSubCommand);
    (0, discord_minimal_1.createGlobalApplicationCommand)(connect4Command);
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, 'minesweeper', 'Play Minesweeper'));
    const ticTacToeCommand = new discord_minimal_1.DiscordApplicationCommand(appId, 'tictactoe', 'Play Tic-Tac-Toe');
    ticTacToeCommand.addOption(vsSubCommand);
    (0, discord_minimal_1.createGlobalApplicationCommand)(ticTacToeCommand);
    const chessCommand = new discord_minimal_1.DiscordApplicationCommand(appId, 'chess', 'Play Chess');
    chessCommand.addOption(vsSubCommand);
    (0, discord_minimal_1.createGlobalApplicationCommand)(chessCommand);
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, 'flood', 'Play Flood'));
    (0, discord_minimal_1.createGlobalApplicationCommand)(new discord_minimal_1.DiscordApplicationCommand(appId, '2048', 'Play 2048'));
}
client.on('interactionCreate', (interaction) => {
    const userGame = getPlayersGame(interaction.guild_id, interaction.member?.user?.id);
    if (interaction.isAppCommand()) {
        if (!interaction.guild_id) {
            const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
            resp.content = 'This command can only be run inside a guild!';
            interaction.respond(resp).catch(console.log);
            return;
        }
        const guildId = interaction.guild_id;
        const userId = interaction.member?.user?.id ?? interaction.user?.id;
        const command = interaction.data?.name;
        if (!command || !userId) {
            const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
            resp.content = 'The command or user was missing somehow.... awkward...';
            interaction.respond(resp).catch(console.log);
            return;
        }
        if (Object.keys(commandGameMap).includes(command)) {
            const game = commandGameMap[command]();
            const player2Option = interaction.data?.options.find(o => o.name === 'vs');
            let player2;
            if (player2Option) {
                if (!game.doesSupportMultiplayer()) {
                    const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
                    resp.content = 'Sorry that game is not a multiplayer game!';
                    interaction.respond(resp).catch(console.log);
                    return;
                }
                else {
                    const users = interaction.data?.resolved?.users;
                    const player2Id = player2Option.value;
                    player2 = player2Id && users ? users[player2Id] : undefined;
                }
            }
            if (userId === player2?.id) {
                const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
                resp.content = 'You cannot play against yourself!';
                interaction.respond(resp).catch(console.log);
                return;
            }
            if (!playerGameMap.has(guildId))
                playerGameMap.set(guildId, new Map());
            if (userGame) {
                const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
                resp.content = 'You must either finish or end your current game (`/endgame`) before you can play another!';
                interaction.respond(resp).catch(console.log);
                return;
            }
            else if (player2 && playerGameMap.get(guildId)?.has(player2.id)) {
                const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
                resp.content = 'The person you are trying to play against is already in a game!';
                interaction.respond(resp).catch(console.log);
                return;
            }
            const foundGame = Array.from(playerGameMap.get(guildId)?.values() ?? []).find(g => g.getGameId() === game.getGameId());
            if (foundGame !== undefined && foundGame.isInGame()) {
                const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
                resp.content = 'Sorry, there can only be 1 instance of a game at a time!';
                interaction.respond(resp).catch(console.log);
                return;
            }
            game.newGame(interaction, player2 ?? null, (result) => {
                playerGameMap.get(guildId)?.delete(userId);
                if (player2)
                    playerGameMap.get(guildId)?.delete(player2.id);
            });
            playerGameMap.get(guildId)?.set(userId, game);
            if (player2)
                playerGameMap.get(guildId)?.set(player2.id, game);
        }
        else if (command === 'endgame') {
            const playerGame = playerGameMap.get(guildId);
            if (!!playerGame && playerGame.has(userId)) {
                const game = playerGame.get(userId);
                if (game) {
                    game.gameOver({ result: game_result_1.ResultType.FORCE_END });
                    if (game?.player2)
                        playerGame.delete(game.player2.id);
                }
                playerGame.delete(userId);
                const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
                resp.content = 'Your game was ended!';
                interaction.respond(resp).catch(console.log);
                return;
            }
            const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
            resp.content = 'Sorry! You must be in a game first!';
            interaction.respond(resp).catch(console.log);
            return;
        }
        else if (command === 'العاب') {
            const embed = new discord_minimal_1.DiscordEmbed()
                .setColor('#fc2eff')
                .setTitle('Available Games')
                .setDescription(`
                🐍 - Snake (/snake)
                
                🅰️ - Hangman (/hangman)
                
                🔵 - Connect4 (/connect4)
                
                💣 - Minesweeper (/minesweeper)
                
                ♟️ - Chess (/chess)
                
                ❌ - Tic-Tac-Toe (/tictactoe)
                
                🟪 - Flood (/flood)
                
                8️⃣ - 2048 (/2048)
                `)
                .setTimestamp();
            const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
            resp.embeds = [embed];
            interaction.respond(resp).catch(_ => console.log('Failed to send list games'));
        }
        else if (command === 'gamesbot') {
            const embed = new discord_minimal_1.DiscordEmbed()
                .setColor('#fc2eff')
                .setTitle('Games Bot')
                .setDescription('Welcome to GamesBot!\n\nThis bot adds lots of little games that you can play right from your Discord chat!\n\nUse `/listgames` to list all available games!\n\nAll games are started via slash commands (ex: `/flood`) and any game can be ended using `/endgame`.\n\nOnly 1 instance of each game may be active at a time and a user can only be playing 1 instance of a game at a time')
                .setTimestamp();
            const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
            resp.embeds = [embed];
            interaction.respond(resp).catch(_ => console.log('Failed to send games bot'));
        }
        return;
    }
    if (!userGame) {
        interaction.deferUpdate().catch(console.log);
        return;
    }
    userGame.onInteraction(interaction);
});
client.on('messageReactionAdd', (reaction) => {
    const userId = reaction.user_id;
    const userGame = getPlayersGame(reaction.guild_id ?? null, userId);
    if (!userGame)
        return;
    if (userGame.player1Turn && userId !== userGame.gameStarter.id)
        return;
    if (!userGame.player1Turn && !!userGame.player2?.id && userId !== userGame.player2.id)
        return;
    if (!userGame.player1Turn && !userGame.player2?.id && userId !== userGame.gameStarter.id)
        return;
    userGame.onReaction(reaction);
    reaction.remove();
});
client.on('messageDelete', (message) => {
    handleMessageDelete(message.guild_id, message.id);
});
client.on('messageDeleteBulk', (messages) => {
    messages.ids.forEach((id) => handleMessageDelete(messages.guild_id, id));
});
const handleMessageDelete = (guild_id, message_id) => {
    if (!guild_id)
        return;
    const guidGames = playerGameMap.get(guild_id);
    if (!guidGames)
        return;
    guidGames.forEach((game, userId) => {
        if (game.getMessageId() === message_id)
            game.gameOver({ result: game_result_1.ResultType.DELETED });
    });
};
const getPlayersGame = (guildId, userId) => {
    if (!guildId)
        return null;
    const guidGames = playerGameMap.get(guildId);
    if (!guidGames)
        return null;
    const userGame = guidGames.get(userId);
    if (!userGame)
        return null;
    return userGame;
};
client.login(config_1.token);
