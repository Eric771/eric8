"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const discord_minimal_1 = require("discord-minimal");
const direction_1 = require("./direction");
const game_base_1 = __importDefault(require("./game-base"));
const game_result_1 = require("./game-result");
const position_1 = require("./position");
const WIDTH = 4;
const HEIGHT = 4;
class TwentyFortyEightGame extends game_base_1.default {
    constructor() {
        super('2048', false);
        this.mergedPos = [];
        this.gameBoard = Array.from({ length: WIDTH * HEIGHT }, () => 0);
        this.placeRandomNewTile();
        this.score = 0;
    }
    getBaseEmbed() {
        return new discord_minimal_1.DiscordEmbed()
            .setColor('#f2e641')
            .setTitle('2048')
            .setAuthor('Made By: Eric', 'https://i.ibb.co/xXZxMT0/1.webp[/img][/url]')
            .setImage(`https://api.theturkey.dev/discordgames/gen2048?gb=${this.gameBoard.join(',')}`)
            .setTimestamp();
    }
    getContent() {
        const row = super.createMessageActionRowButton([['left', '⬅️'], ['up', '⬆️'], ['right', '➡️'], ['down', '⬇️']]);
        const embed = this.getBaseEmbed()
            .addField('Score:', this.score.toString())
            .setFooter(`Currently Playing: ${this.gameStarter.username}`);
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [embed];
        resp.components = [row];
        return resp;
    }
    getGameOverContent(result) {
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [new discord_minimal_1.DiscordEmbed().setDescription(`GAME OVER!\nScore: ${this.score}`).setFooter(`Player: ${this.gameStarter.username}`)];
        return resp;
    }
    placeRandomNewTile() {
        const newPos = { x: 0, y: 0 };
        do {
            newPos.x = Math.floor(Math.random() * WIDTH);
            newPos.y = Math.floor(Math.random() * HEIGHT);
        } while (this.gameBoard[newPos.y * WIDTH + newPos.x] != 0);
        this.gameBoard[newPos.y * WIDTH + newPos.x] = (Math.random() * 100) < 25 ? 2 : 1;
    }
    shiftLeft() {
        let moved = false;
        for (let y = 0; y < HEIGHT; y++)
            for (let x = 1; x < WIDTH; x++)
                moved = this.shift({ x, y }, direction_1.Direction.LEFT) || moved;
        return moved;
    }
    shiftRight() {
        let moved = false;
        for (let y = 0; y < HEIGHT; y++)
            for (let x = WIDTH - 2; x >= 0; x--)
                moved = this.shift({ x, y }, direction_1.Direction.RIGHT) || moved;
        return moved;
    }
    shiftUp() {
        let moved = false;
        for (let x = 0; x < WIDTH; x++)
            for (let y = 1; y < HEIGHT; y++)
                moved = this.shift({ x, y }, direction_1.Direction.UP) || moved;
        return moved;
    }
    shiftDown() {
        let moved = false;
        for (let x = 0; x < WIDTH; x++)
            for (let y = HEIGHT - 2; y >= 0; y--)
                moved = this.shift({ x, y }, direction_1.Direction.DOWN) || moved;
        return moved;
    }
    shift(pos, dir) {
        let moved = false;
        const movingNum = this.gameBoard[pos.y * WIDTH + pos.x];
        if (movingNum === 0)
            return false;
        let moveTo = pos;
        let set = false;
        while (!set) {
            moveTo = (0, position_1.move)(moveTo, dir);
            const moveToNum = this.gameBoard[moveTo.y * WIDTH + moveTo.x];
            if (!(0, position_1.isInside)(moveTo, WIDTH, HEIGHT) || (moveToNum != 0 && moveToNum !== movingNum) || !!this.mergedPos.find(p => p.x === moveTo.x && p.y === moveTo.y)) {
                const oppDir = (0, direction_1.oppositeDir)(dir);
                const moveBack = (0, position_1.move)(moveTo, oppDir);
                if (!(0, position_1.posEqual)(moveBack, pos)) {
                    this.gameBoard[pos.y * WIDTH + pos.x] = 0;
                    this.gameBoard[moveBack.y * WIDTH + moveBack.x] = movingNum;
                    moved = true;
                }
                set = true;
            }
            else if (moveToNum === movingNum) {
                moved = true;
                this.gameBoard[moveTo.y * WIDTH + moveTo.x] += 1;
                this.score += Math.floor(Math.pow(this.gameBoard[moveTo.y * WIDTH + moveTo.x], 2));
                this.gameBoard[pos.y * WIDTH + pos.x] = 0;
                set = true;
                this.mergedPos.push(moveTo);
            }
        }
        return moved;
    }
    isBoardFull() {
        return !this.gameBoard.includes(0);
    }
    numMovesPossible() {
        let numMoves = 0;
        for (let y = 0; y < HEIGHT; y++) {
            for (let x = 0; x < WIDTH; x++) {
                const pos = { x, y };
                const posNum = this.gameBoard[pos.y * WIDTH + pos.x];
                [direction_1.Direction.DOWN, direction_1.Direction.LEFT, direction_1.Direction.RIGHT, direction_1.Direction.UP].forEach(dir => {
                    const newPos = (0, position_1.move)(pos, dir);
                    if ((0, position_1.isInside)(newPos, WIDTH, HEIGHT) && (this.gameBoard[newPos.y * WIDTH + newPos.x] === 0 || this.gameBoard[newPos.y * WIDTH + newPos.x] === posNum))
                        numMoves++;
                });
            }
        }
        return numMoves;
    }
    onInteraction(interaction) {
        if (!interaction.isButton())
            return;
        let moved = false;
        this.mergedPos = [];
        switch (interaction.data?.custom_id) {
            case 'left':
                moved = this.shiftLeft();
                break;
            case 'up':
                moved = this.shiftUp();
                break;
            case 'right':
                moved = this.shiftRight();
                break;
            case 'down':
                moved = this.shiftDown();
                break;
        }
        if (moved)
            this.placeRandomNewTile();
        super.step(false);
        if (this.isBoardFull() && this.numMovesPossible() == 0)
            this.gameOver({ result: game_result_1.ResultType.LOSER, name: this.gameStarter.username, score: `${this.score}` }, interaction);
        else
            interaction.update(this.getContent()).catch(e => super.handleError(e, 'update interaction'));
    }
    onReaction(reaction) { }
}
exports.default = TwentyFortyEightGame;
