"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const game_base_1 = __importDefault(require("./game-base"));
const game_result_1 = require("./game-result");
const node_fetch_1 = __importDefault(require("node-fetch"));
const discord_minimal_1 = require("discord-minimal");
//unicode fun...
const reactions = new Map([
    ['🅰️', 'A'],
    ['🇦', 'A'],
    ['🅱️', 'B'],
    ['🇧', 'B'],
    ['🇨', 'C'],
    ['🇩', 'D'],
    ['🇪', 'E'],
    ['🇫', 'F'],
    ['🇬', 'G'],
    ['🇭', 'H'],
    ['ℹ️', 'I'],
    ['🇮', 'I'],
    ['🇯', 'J'],
    ['🇰', 'K'],
    ['🇱', 'L'],
    ['Ⓜ️', 'M'],
    ['🇲', 'M'],
    ['🇳', 'N'],
    ['🅾️', 'O'],
    ['⭕', 'O'],
    ['🇴', 'O'],
    ['🅿️', 'P'],
    ['🇵', 'P'],
    ['🇶', 'Q'],
    ['🇷', 'R'],
    ['🇸', 'S'],
    ['🇹', 'T'],
    ['🇺', 'U'],
    ['🇻', 'V'],
    ['🇼', 'W'],
    ['✖️', 'X'],
    ['❎', 'X'],
    ['❌', 'X'],
    ['🇽', 'X'],
    ['🇾', 'Y'],
    ['💤', 'Z'],
    ['🇿', 'Z'],
]);
class HangmanGame extends game_base_1.default {
    constructor() {
        super('hangman', false);
        this.word = '';
        this.guessed = [];
        this.wrongs = 0;
    }
    newGame(interaction, player2, onGameEnd) {
        if (this.inGame)
            return;
        (0, node_fetch_1.default)('https://api.theturkey.dev/randomword').then(resp => resp.text())
            .then(word => {
            this.word = word.toUpperCase();
            this.guessed = [];
            this.wrongs = 0;
            super.newGame(interaction, player2, onGameEnd);
        }).catch(() => console.log('Failed to fetch random word!'));
    }
    getBaseEmbed() {
        return new discord_minimal_1.DiscordEmbed()
            .setColor('#db9a00')
            .setTitle('Hangman')
            .setAuthor('Made By: Eric', 'https://i.ibb.co/xXZxMT0/1.webp[/img][/url]')
            .setTimestamp();
    }
    getContent() {
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [this.getBaseEmbed()
                .setDescription(this.getDescription())
                .addField('Letters Guessed', this.guessed.length == 0 ? '\u200b' : this.guessed.join(' '))
                .addField('How To Play', 'React to this message using the emojis that look like letters (🅰️, 🇹, )')
                .setFooter(`Currently Playing: ${this.gameStarter.username}`)];
        return resp;
    }
    getGameOverContent(result) {
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.embeds = [this.getBaseEmbed().setDescription(`${this.getWinnerText(result)}\n\nThe Word was:\n${this.word}\n\n${this.getDescription()}`)];
        return resp;
    }
    makeGuess(reaction) {
        if (reactions.has(reaction)) {
            const letter = reactions.get(reaction);
            if (letter === undefined)
                return;
            if (!this.guessed.includes(letter)) {
                this.guessed.push(letter);
                if (this.word.indexOf(letter) == -1) {
                    this.wrongs++;
                    if (this.wrongs == 5) {
                        this.gameOver({ result: game_result_1.ResultType.LOSER, name: this.gameStarter.username, score: this.word });
                        return;
                    }
                }
                else if (!this.word.split('').map(l => this.guessed.includes(l) ? l : '_').includes('_')) {
                    this.gameOver({ result: game_result_1.ResultType.WINNER, name: this.gameStarter.username, score: this.word });
                    return;
                }
            }
        }
        this.step(true);
    }
    getDescription() {
        return '```'
            + '|‾‾‾‾‾‾|   \n|     '
            + (this.wrongs > 0 ? '🎩' : ' ')
            + '   \n|     '
            + (this.wrongs > 1 ? '😟' : ' ')
            + '   \n|     '
            + (this.wrongs > 2 ? '👕' : ' ')
            + '   \n|     '
            + (this.wrongs > 3 ? '🩳' : ' ')
            + '   \n|    '
            + (this.wrongs > 4 ? '👞👞' : ' ')
            + '   \n|     \n|__________\n\n'
            + this.word.split('').map(l => this.guessed.includes(l) ? l : '_').join(' ')
            + '```';
    }
    onReaction(reaction) {
        const reactName = reaction.emoji.name;
        if (reactName)
            this.makeGuess(reactName);
        else
            this.step(true);
    }
    onInteraction(interaction) { }
}
exports.default = HangmanGame;
