"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.token = void 0;
const token = 'MTIxNDk0OTg0OTI1OTE4ODI4NA.GuG6oR.w5LRimt6ercBUZysp91D80SvJH827Iv67XZo0A';
exports.token = token;
