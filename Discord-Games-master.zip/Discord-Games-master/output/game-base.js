"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_minimal_1 = require("discord-minimal");
const game_result_1 = require("./game-result");
class GameBase {
    constructor(gameType, isMultiplayerGame) {
        this.inGame = false;
        this.result = undefined;
        this.gameMessage = undefined;
        this.player2 = null;
        this.player1Turn = true;
        this.onGameEnd = () => { };
        this.gameType = gameType;
        this.isMultiplayerGame = isMultiplayerGame;
    }
    newGame(interaction, player2, onGameEnd) {
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        this.gameStarter = interaction.user ?? interaction.member.user;
        this.player2 = player2;
        this.onGameEnd = onGameEnd;
        this.inGame = true;
        const resp = new discord_minimal_1.DiscordInteractionResponseMessageData();
        resp.content = 'بدأت اللعبة انجوي';
        interaction.respond(resp).catch(console.log);
        const content = this.getContent();
        interaction.sendMessageInChannel({ embeds: content.embeds, components: content.components }).then(msg => {
            this.gameMessage = msg;
            this.gameTimeoutId = setTimeout(() => this.gameOver({ result: game_result_1.ResultType.TIMEOUT }), 60000);
        }).catch(e => this.handleError(e, 'send message/ embed'));
    }
    step(edit = false) {
        if (edit)
            this.gameMessage?.edit(this.getContent());
        if (this.gameTimeoutId)
            clearTimeout(this.gameTimeoutId);
        this.gameTimeoutId = setTimeout(() => this.gameOver({ result: game_result_1.ResultType.TIMEOUT }), 60000);
    }
    handleError(e, perm) {
        if (e instanceof discord_minimal_1.DiscordAPIError) {
            const de = e;
            switch (de.code) {
                case 10003:
                    this.gameOver({ result: game_result_1.ResultType.ERROR, error: 'Channel not found!' });
                    break;
                case 10008:
                    this.gameOver({ result: game_result_1.ResultType.DELETED, error: 'Message was deleted!' });
                    break;
                case 10062:
                    console.log('Unknown Interaction??');
                    break;
                case 50001:
                    if (this.gameMessage)
                        this.gameMessage.sendMessageInChannel('The bot is missing access to preform some of it\'s actions!').catch(() => {
                            console.log('Error in the access error handler!');
                        });
                    else
                        console.log('Error in the access error handler!');
                    this.gameOver({ result: game_result_1.ResultType.ERROR, error: 'Missing access!' });
                    break;
                case 50013:
                    if (this.gameMessage)
                        this.gameMessage.sendMessageInChannel(`The bot is missing the '${perm}' permissions it needs order to work!`).catch(() => {
                            console.log('Error in the permission error handler!');
                        });
                    else
                        console.log('Error in the permission error handler!');
                    this.gameOver({ result: game_result_1.ResultType.ERROR, error: 'Missing permissions!' });
                    break;
                default:
                    console.log('Encountered a Discord error not handled! ');
                    console.log(e);
                    break;
            }
        }
        else {
            this.gameOver({ result: game_result_1.ResultType.ERROR, error: 'Game embed missing!' });
        }
    }
    gameOver(result, interaction = undefined) {
        if (!this.inGame)
            return;
        this.result = result;
        this.inGame = false;
        const gameOverContent = this.getGameOverContent(result);
        if (result.result !== game_result_1.ResultType.FORCE_END) {
            this.onGameEnd(result);
            this.gameMessage?.edit(gameOverContent).catch(e => this.handleError(e, ''));
            this.gameMessage?.removeAllReactions();
        }
        else {
            if (interaction)
                interaction.update(gameOverContent).catch(e => this.handleError(e, 'update interaction'));
            else
                this.gameMessage?.edit(gameOverContent).catch(e => this.handleError(e, ''));
        }
        if (this.gameTimeoutId)
            clearTimeout(this.gameTimeoutId);
    }
    getWinnerText(result) {
        if (result.result === game_result_1.ResultType.TIE)
            return 'It was a tie!';
        else if (result.result === game_result_1.ResultType.TIMEOUT)
            return 'The game went unfinished :(';
        else if (result.result === game_result_1.ResultType.FORCE_END)
            return 'The game was ended';
        else if (result.result === game_result_1.ResultType.ERROR)
            return 'ERROR: ' + result.error;
        else if (result.result === game_result_1.ResultType.WINNER)
            return '`' + result.name + '` has won!';
        else if (result.result === game_result_1.ResultType.LOSER)
            return '`' + result.name + '` has lost!';
        return '';
    }
    setGameId(id) {
        this.gameId = id;
    }
    getGameId() {
        return this.gameId;
    }
    getGameType() {
        return this.gameType;
    }
    getMessageId() {
        return this.gameMessage?.id ?? '';
    }
    isInGame() {
        return this.inGame;
    }
    doesSupportMultiplayer() {
        return this.isMultiplayerGame;
    }
    createMessageActionRowButton(buttonInfo) {
        return new discord_minimal_1.DiscordMessageActionRow()
            .addComponents(...buttonInfo.map(([id, label]) => new discord_minimal_1.DiscordMessageButton(discord_minimal_1.DiscordButtonStyle.SECONDARY)
            .setCustomId(id)
            .setLabel(label)));
    }
}
exports.default = GameBase;
