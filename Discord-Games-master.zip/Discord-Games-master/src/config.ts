const token = 'MTIxNDk0OTg0OTI1OTE4ODI4NA.GuG6oR.w5LRimt6ercBUZysp91D80SvJH827Iv67XZo0A';

export { token };
