interface GameResult {
    result: ResultType;
    error?: string;
    name?: string;
    score?: string;
}

export default GameResult;

export enum ResultType {
    TIMEOUT = 'انتهى الوقت',
    FORCE_END = 'force_end',
    WINNER = 'الفائز',
    LOSER = 'الخاسر',
    TIE = 'tie',
    ERROR = 'حدث خطأ',
    DELETED = 'محذوف',
}